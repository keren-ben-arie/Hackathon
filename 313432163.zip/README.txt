classifier.py - file with predict and send_police_cars.
train_models.py - this is the file that we used to train our model and "pickle" it. 
project.pdf - description of our project.
USERS - user file (users and IDs)
README - this file :)
crimes_dataset_part2.csv - surprise data set
Dataset_crimes.csv - first data set
requirements.txt — the required packages for your virtual environment, as described above.